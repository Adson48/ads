// Marketing Ads JavaScript

// Notification management
const notificationForm = document.getElementById('notificationForm');
const notificationList = document.getElementById('notificationList');
const telegramBotTokenInput = document.getElementById('telegramBotToken');
const telegramChatIdInput = document.getElementById('telegramChatId');
const saveTelegramConfigBtn = document.getElementById('saveTelegramConfigBtn');
const testTelegramBtn = document.getElementById('testTelegramBtn');
const telegramConfigStatus = document.getElementById('telegramConfigStatus');
const telegramDebugOutput = document.getElementById('telegramDebugOutput');
const sendToTelegramCheckbox = document.getElementById('sendToTelegram');
const telegramSendEnabledKey = 'telegramSendEnabled';
let homeAlertBanner = document.getElementById('homeAlertBanner');
let homeAlertList = document.getElementById('homeAlertList');

// Create alert banner in DOM if it doesn't exist yet
if (!homeAlertBanner) {
    homeAlertBanner = document.createElement('section');
    homeAlertBanner.id = 'homeAlertBanner';
    homeAlertBanner.className = 'home-alert-banner';
    homeAlertBanner.style.display = 'none';
    homeAlertBanner.innerHTML = '<div class="home-alert-inner"><p class="home-alert-title">CẢNH BÁO CHIẾN DỊCH</p><ul id="homeAlertList" class="home-alert-list"></ul></div>';
    const header = document.querySelector('header');
    if (header && header.parentNode) {
        header.parentNode.insertBefore(homeAlertBanner, header.nextSibling);
    } else {
        document.body.insertBefore(homeAlertBanner, document.body.firstChild);
    }
    homeAlertList = document.getElementById('homeAlertList');
}

const homeAlertState = {
    roasThreshold: 1.5,
    roasValue: null,
    overdueTasks: []
};

const renderHomeAlerts = function() {
    if (!homeAlertBanner || !homeAlertList) {
        return;
    }

    const messages = [];

    if (typeof homeAlertState.roasValue === 'number' && homeAlertState.roasValue < homeAlertState.roasThreshold) {
        const roasText = homeAlertState.roasValue.toFixed(2);
        messages.push('ROAS hiện tại = ' + roasText + ' (thấp hơn mức cho phép ' + homeAlertState.roasThreshold.toFixed(2) + ').');
    }

    homeAlertState.overdueTasks.forEach(function(task) {
        messages.push('Công việc quá hạn: ' + task.text + ' (hạn chót ' + task.dueDate + ').');
    });

    if (!messages.length) {
        homeAlertBanner.style.display = 'none';
        homeAlertList.innerHTML = '';
        return;
    }

    homeAlertList.innerHTML = messages.map(function(msg) {
        return '<li>' + msg + '</li>';
    }).join('');
    homeAlertBanner.removeAttribute('hidden');
    homeAlertBanner.style.display = 'block';
};

const setRoasAlertContext = function(currentCost, currentRevenue) {
    if (!currentCost) {
        homeAlertState.roasValue = null;
    } else {
        homeAlertState.roasValue = Number((currentRevenue / currentCost).toFixed(4));
    }
    renderHomeAlerts();
};

const setChecklistOverdueContext = function(items) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    homeAlertState.overdueTasks = (items || []).filter(function(item) {
        if (!item || item.checked || !item.text || !item.dueDate) {
            return false;
        }

        const due = new Date(item.dueDate);
        if (Number.isNaN(due.getTime())) {
            return false;
        }

        due.setHours(0, 0, 0, 0);
        return due < today;
    }).slice(0, 5);

    renderHomeAlerts();
};

const parseDashboardCurrencyInput = function(element) {
    return Number(String((element && element.value) || '').replace(/[^0-9]/g, '')) || 0;
};

const hydrateHomeAlerts = function() {
    const budgetEl = document.getElementById('budgetInput');
    const dailyBudgetEl = document.getElementById('dailyBudgetInput');

    const budgetValue = parseDashboardCurrencyInput(budgetEl);
    const dailyBudgetValue = parseDashboardCurrencyInput(dailyBudgetEl);

    if (budgetValue) {
        setRoasAlertContext(budgetValue, dailyBudgetValue);
    }

    try {
        const savedChecklist = JSON.parse(localStorage.getItem('homeChecklistItems') || 'null');
        if (Array.isArray(savedChecklist)) {
            setChecklistOverdueContext(savedChecklist);
        } else {
            renderHomeAlerts();
        }
    } catch (e) {
        renderHomeAlerts();
    }
};

// Site-wide Telegram target: set your bot token/chat ID here to send from all visitors.
const siteTelegramDefaults = {
    botToken: '8783849728:AAGxfnR4xv506LarXr3TqAMX53Y2BFsYlRE',
    chatId: '6437855532'
};

const hasSiteTelegramDefaults = function() {
    return Boolean(siteTelegramDefaults.botToken && siteTelegramDefaults.chatId);
};

const buildTelegramApiUrl = function(botToken, method) {
    return 'https://api.telegram.org/bot' + String(botToken || '').trim() + '/' + method;
};

const getTelegramConfig = function() {
    if (hasSiteTelegramDefaults()) {
        return {
            botToken: siteTelegramDefaults.botToken,
            chatId: siteTelegramDefaults.chatId
        };
    }

    return {
        botToken: (telegramBotTokenInput && telegramBotTokenInput.value.trim()) || localStorage.getItem('telegramBotToken') || '',
        chatId: (telegramChatIdInput && telegramChatIdInput.value.trim()) || localStorage.getItem('telegramChatId') || ''
    };
};

const persistTelegramConfig = function(showStatus) {
    const botToken = telegramBotTokenInput ? telegramBotTokenInput.value.trim() : '';
    const chatId = telegramChatIdInput ? telegramChatIdInput.value.trim() : '';

    if (botToken) {
        localStorage.setItem('telegramBotToken', botToken);
    } else {
        localStorage.removeItem('telegramBotToken');
    }

    if (chatId) {
        localStorage.setItem('telegramChatId', chatId);
    } else {
        localStorage.removeItem('telegramChatId');
    }

    if (showStatus && telegramConfigStatus) {
        telegramConfigStatus.textContent = 'Đã lưu cấu hình Telegram thành công.';
    }
};

const dataUrlToBlob = function(dataUrl) {
    const parts = String(dataUrl || '').split(',');
    const metadata = parts[0] || '';
    const raw = parts[1] || '';
    const mimeMatch = metadata.match(/:(.*?);/);
    const mime = mimeMatch ? mimeMatch[1] : 'image/jpeg';
    const binary = atob(raw);
    const bytes = new Uint8Array(binary.length);

    for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
    }

    return new Blob([bytes], { type: mime });
};

const sendTelegramNotification = async function(payload) {
    persistTelegramConfig(false);
    const config = getTelegramConfig();
    if (!config.botToken || !config.chatId) {
        return { ok: false, error: 'missing-config' };
    }

    const title = payload && payload.title ? payload.title : 'Thông báo mới';
    const content = payload && payload.content ? payload.content : '';
    const date = payload && payload.date ? payload.date : new Date().toLocaleString('vi-VN');
    const image = payload && payload.image ? payload.image : null;

    try {
        if (image) {
            const formData = new FormData();
            formData.append('chat_id', config.chatId);
            formData.append('caption', '📢 ' + title + '\n' + content + '\n🕒 ' + date);
            formData.append('photo', dataUrlToBlob(image), 'notification-image.jpg');

            const photoResponse = await fetch(buildTelegramApiUrl(config.botToken, 'sendPhoto'), {
                method: 'POST',
                body: formData
            });
            const photoData = await photoResponse.json().catch(() => ({}));

            if (!photoResponse.ok || !photoData.ok) {
                throw new Error(photoData.description || 'send-photo-failed');
            }

            return { ok: true };
        }

        const messageResponse = await fetch(buildTelegramApiUrl(config.botToken, 'sendMessage'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chat_id: config.chatId,
                text: '📢 ' + title + '\n' + content + '\n🕒 ' + date
            })
        });
        const messageData = await messageResponse.json().catch(() => ({}));

        if (!messageResponse.ok || !messageData.ok) {
            throw new Error(messageData.description || 'send-message-failed');
        }

        return { ok: true };
    } catch (error) {
        return { ok: false, error: error && error.message ? error.message : 'telegram-send-failed' };
    }
};

if (telegramBotTokenInput && telegramChatIdInput) {
    telegramBotTokenInput.value = localStorage.getItem('telegramBotToken') || '';
    telegramChatIdInput.value = localStorage.getItem('telegramChatId') || '';

    telegramBotTokenInput.addEventListener('input', function() {
        persistTelegramConfig(false);
    });

    telegramChatIdInput.addEventListener('input', function() {
        persistTelegramConfig(false);
    });
}

if (sendToTelegramCheckbox) {
    const savedSendSetting = localStorage.getItem(telegramSendEnabledKey);
    if (savedSendSetting !== null) {
        sendToTelegramCheckbox.checked = savedSendSetting === '1';
    }

    sendToTelegramCheckbox.addEventListener('change', function() {
        localStorage.setItem(telegramSendEnabledKey, this.checked ? '1' : '0');
    });
}

if (saveTelegramConfigBtn) {
    saveTelegramConfigBtn.addEventListener('click', function() {
        const config = getTelegramConfig();

        if (!config.botToken || !config.chatId) {
            if (telegramConfigStatus) {
                telegramConfigStatus.textContent = 'Vui lòng nhập đầy đủ Bot Token và Chat ID.';
            }
            return;
        }

        persistTelegramConfig(true);
    });
}

if (testTelegramBtn) {
    testTelegramBtn.addEventListener('click', async function() {
        persistTelegramConfig(false);
        const config = getTelegramConfig();

        if (!config.botToken) {
            if (telegramConfigStatus) {
                telegramConfigStatus.textContent = 'Thiếu Bot Token.';
            }
            return;
        }

        if (telegramDebugOutput) {
            telegramDebugOutput.textContent = 'Đang kiểm tra kết nối Telegram...';
        }

        try {
            const meResponse = await fetch(buildTelegramApiUrl(config.botToken, 'getMe'));
            const meData = await meResponse.json().catch(() => ({}));

            const updatesResponse = await fetch(buildTelegramApiUrl(config.botToken, 'getUpdates'));
            const updatesData = await updatesResponse.json().catch(() => ({}));

            let probeData = null;
            if (config.chatId) {
                const probeResponse = await fetch(buildTelegramApiUrl(config.botToken, 'sendMessage'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        chat_id: config.chatId,
                        text: 'Test kết nối từ Marketing Ads: ' + new Date().toLocaleString('vi-VN')
                    })
                });
                probeData = await probeResponse.json().catch(() => ({}));
            }

            if (telegramDebugOutput) {
                telegramDebugOutput.textContent = [
                    'getMe:',
                    JSON.stringify(meData, null, 2),
                    '',
                    'getUpdates:',
                    JSON.stringify(updatesData, null, 2),
                    '',
                    'sendMessage(test):',
                    probeData ? JSON.stringify(probeData, null, 2) : 'Bỏ qua vì chưa nhập Chat ID'
                ].join('\n');
            }

            if (telegramConfigStatus) {
                telegramConfigStatus.textContent = 'Đã test xong. Xem kết quả chi tiết ở khung debug.';
            }
        } catch (error) {
            if (telegramConfigStatus) {
                telegramConfigStatus.textContent = 'Loi khi test Telegram.';
            }
            if (telegramDebugOutput) {
                telegramDebugOutput.textContent = 'Loi: ' + (error && error.message ? error.message : 'unknown');
            }
        }
    });
}

// Image preview
const notifImageInput = document.getElementById('notifImage');
if (notifImageInput) {
    notifImageInput.addEventListener('change', function() {
        const preview = document.getElementById('imagePreview');
        preview.innerHTML = '';
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.innerHTML = `<img src="${e.target.result}" style="max-width:100%;max-height:180px;border-radius:10px;border:1px solid rgba(199,81,124,0.25);">`;
            };
            reader.readAsDataURL(file);
        }
    });
}

if (notificationForm) {
    notificationForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        const title = document.getElementById('title').value;
        const content = document.getElementById('content').value;
        const imageFile = document.getElementById('notifImage').files[0];

        const saveNotification = async function(imageDataUrl) {
            const notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
            const newNotification = {
                id: Date.now(),
                title: title,
                content: content,
                date: new Date().toLocaleString('vi-VN'),
                image: imageDataUrl || null
            };
            notifications.unshift(newNotification);
            localStorage.setItem('notifications', JSON.stringify(notifications));
            displayNotifications();

            let alertMessage = `Thông báo "${title}" đã được đăng thành công!`;
            const shouldSendTelegram = hasSiteTelegramDefaults() || (sendToTelegramCheckbox && sendToTelegramCheckbox.checked);
            if (shouldSendTelegram) {
                const telegramResult = await sendTelegramNotification(newNotification);
                if (telegramResult.ok) {
                    alertMessage += '\nĐã gửi lên Telegram.';
                } else if (telegramResult.error === 'missing-config') {
                    alertMessage += '\nChưa gửi Telegram vì thiếu Bot Token/Chat ID.';
                } else {
                    alertMessage += '\nGửi Telegram thất bại: ' + telegramResult.error;
                }
            }

            alert(alertMessage);
            const titleInput = document.getElementById('title');
            const contentInput = document.getElementById('content');
            if (titleInput) {
                titleInput.value = '';
            }
            if (contentInput) {
                contentInput.value = '';
            }
            if (notifImageInput) {
                notifImageInput.value = '';
            }
            const preview = document.getElementById('imagePreview');
            if (preview) {
                preview.innerHTML = '';
            }
        };

        if (title && content) {
            if (imageFile) {
                const reader = new FileReader();
                reader.onload = async function(e) { await saveNotification(e.target.result); };
                reader.readAsDataURL(imageFile);
            } else {
                await saveNotification(null);
            }
        } else {
            alert('Vui lòng điền đầy đủ thông tin!');
        }
    });
}

// Function to display notifications
function displayNotifications() {
    if (!notificationList) return;

    const notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
    notificationList.innerHTML = '';

    if (notifications.length === 0) {
        notificationList.innerHTML = '<p class="no-notifications">Chưa có thông báo nào.</p>';
        return;
    }

    notifications.forEach(notification => {
        const notificationDiv = document.createElement('div');
        notificationDiv.className = 'notification-item';
        notificationDiv.innerHTML = `
            <h3>${notification.title}</h3>
            <p class="notification-date">${notification.date}</p>
            <p class="notification-content">${notification.content}</p>
            ${notification.image ? `<img src="${notification.image}" style="max-width:100%;max-height:280px;border-radius:12px;margin-bottom:1rem;border:1px solid rgba(199,81,124,0.2);">` : ''}
            <button class="btn-delete-notification" onclick="deleteNotification(${notification.id})">🗑️ Xóa</button>
        `;
        notificationList.appendChild(notificationDiv);
    });
}

// Function to delete notification
function deleteNotification(id) {
    const notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
    const filtered = notifications.filter(n => n.id !== id);
    localStorage.setItem('notifications', JSON.stringify(filtered));
    displayNotifications();
}

// Load notifications on page load
document.addEventListener('DOMContentLoaded', function() {
    displayNotifications();
    hydrateHomeAlerts();
    setTimeout(hydrateHomeAlerts, 800);
});

hydrateHomeAlerts();
setTimeout(hydrateHomeAlerts, 300);

// Content studio interactions
const studioOutput = document.getElementById('studioOutput');
const sidebarCategoryLinks = document.querySelectorAll('.sidebar-menu a[data-category]');

if (studioOutput && sidebarCategoryLinks.length) {
    const fetchGoogleResultsViaMirror = async function(cx, query) {
        if (!cx) {
            throw new Error('missing-cx-for-mirror');
        }

        const mirrorUrl = 'https://r.jina.ai/http://cse.google.com/cse?cx=' + encodeURIComponent(cx) + '&q=' + encodeURIComponent(query);
        const response = await fetch(mirrorUrl);
        if (!response.ok) {
            throw new Error('google-mirror-failed');
        }

        const text = await response.text();
        const lines = text.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
        const results = [];
        const seen = new Set();

        for (let i = 0; i < lines.length; i++) {
            const line = lines[i];
            if (!/^https?:\/\//i.test(line)) {
                continue;
            }

            const link = line;
            const lower = link.toLowerCase();
            if (
                lower.includes('cse.google.com') ||
                lower.includes('google.com/cse/static') ||
                lower.includes('encrypted-tbn0.gstatic.com')
            ) {
                continue;
            }

            if (seen.has(link)) {
                continue;
            }

            const prev = (lines[i - 1] || '').trim();
            const next = (lines[i + 1] || '').trim();
            const title = prev && !/^https?:\/\//i.test(prev) ? prev : link;
            const snippet = next && !/^https?:\/\//i.test(next) ? next : 'Ket qua tim kiem thuc tu Google Programmable Search.';

            seen.add(link);
            results.push({ title, link, snippet });

            if (results.length >= 10) {
                break;
            }
        }

        return results;
    };

    const buildCseLink = function(cx, query) {
        if (!cx) {
            return '';
        }

        return 'https://cse.google.com/cse?cx=' + encodeURIComponent(cx) + '#gsc.tab=0&gsc.q=' + encodeURIComponent(query);
    };

    const tryOpenCseFallback = function(link) {
        if (!link) {
            return false;
        }

        const key = 'cseFallbackOpened:' + link;
        if (sessionStorage.getItem(key) === '1') {
            return false;
        }

        sessionStorage.setItem(key, '1');
        const opened = window.open(link, '_blank', 'noopener,noreferrer');
        return !!opened;
    };

    const fetchGoogleRealResults = async function(query) {
        const apiKey = localStorage.getItem('googleApiKey');
        const cx = localStorage.getItem('googleCx');

        if (!apiKey || !cx) {
            throw new Error('missing-google-api-config');
        }

        const endpoint = 'https://www.googleapis.com/customsearch/v1?key=' + encodeURIComponent(apiKey) + '&cx=' + encodeURIComponent(cx) + '&q=' + encodeURIComponent(query) + '&num=10';
        const response = await fetch(endpoint);
        const data = await response.json().catch(() => ({}));

        if (!response.ok || data.error) {
            const apiErrorMessage = data.error && data.error.message ? data.error.message : 'google-api-failed';
            throw new Error('google-api-failed::' + apiErrorMessage);
        }

        return Array.isArray(data.items) ? data.items : [];
    };

    const renderStudioContent = function(category) {
        if (category === 'library') {
            const savedApiKey = localStorage.getItem('googleApiKey') || '';
            const savedCx = localStorage.getItem('googleCx') || '';

            studioOutput.innerHTML = `
                <h3>Nội dung từ Thư viện mẫu</h3>
                <div class="studio-api-config">
                    <p class="studio-config-title">Cấu hình Google Search API</p>
                    <input id="googleApiKeyInput" class="studio-config-input" type="text" placeholder="Nhập Google API Key" value="${savedApiKey}">
                    <input id="googleCxInput" class="studio-config-input" type="text" placeholder="Nhập Google CX (Search Engine ID)" value="${savedCx}">
                    <button id="saveGoogleConfigBtn" class="studio-config-btn" type="button">Lưu cấu hình</button>
                    <p id="googleConfigStatus" class="studio-config-status"></p>
                </div>
                <div class="studio-dropdown-wrap">
                    <label for="studioTemplateSelect" class="studio-dropdown-label">Chọn mẫu nội dung</label>
                    <select id="studioTemplateSelect" class="studio-dropdown-select">
                        <option value="title" selected>Mẫu tiêu đề</option>
                        <option value="facebook-ads">Mẫu bài viết Facebook/Ads</option>
                        <option value="short-video">Kịch bản Video ngắn</option>
                    </select>
                </div>
                <div id="studioSelectedContent" class="studio-selected-content"></div>
            `;

            const studioTemplateSelect = document.getElementById('studioTemplateSelect');
            const studioSelectedContent = document.getElementById('studioSelectedContent');
            const googleApiKeyInput = document.getElementById('googleApiKeyInput');
            const googleCxInput = document.getElementById('googleCxInput');
            const saveGoogleConfigBtn = document.getElementById('saveGoogleConfigBtn');
            const googleConfigStatus = document.getElementById('googleConfigStatus');
            const fixedQuery = '100+ cấu trúc giật tít thu hút click';

            const loadTitleResults = async function() {
                if (!studioSelectedContent) {
                    return;
                }

                studioSelectedContent.innerHTML = '<p class="studio-loading">Đang lấy kết quả thực từ Google...</p>';
                const currentCx = (googleCxInput && googleCxInput.value.trim()) || localStorage.getItem('googleCx') || '';

                try {
                    const searchItems = await fetchGoogleRealResults(fixedQuery);

                    if (!searchItems.length) {
                        studioSelectedContent.innerHTML = '<p>Không có kết quả thực từ Google cho truy vấn này.</p>';
                        return;
                    }

                    const directLink = 'https://www.google.com/search?q=' + encodeURIComponent(fixedQuery);
                    const htmlItems = searchItems.slice(0, 10).map((item, index) => {
                        const title = item.title || 'Kết quả từ Google';
                        const link = item.link || directLink;
                        const snippet = item.snippet || '';
                        return `<li><a href="${link}" target="_blank" rel="noopener noreferrer">Top ${index + 1}: ${title}</a><p>${snippet}</p></li>`;
                    }).join('');

                    studioSelectedContent.innerHTML = `
                        <p class="studio-result-title">Top kết quả Google cho truy vấn: "${fixedQuery}"</p>
                        <p><a href="${directLink}" target="_blank" rel="noopener noreferrer">Mở trang kết quả tìm kiếm Google gốc</a></p>
                        <ul class="studio-google-list">${htmlItems}</ul>
                    `;
                } catch (error) {
                    const directLink = 'https://www.google.com/search?q=' + encodeURIComponent(fixedQuery);
                    const cseLink = buildCseLink(currentCx, fixedQuery);
                    const rawMessage = error && error.message ? error.message : '';
                    let friendlyMessage = 'Không thể lấy kết quả từ Google API.';

                    try {
                        const mirrorResults = await fetchGoogleResultsViaMirror(currentCx, fixedQuery);

                        if (mirrorResults.length) {
                            const htmlMirrorItems = mirrorResults.map((item, index) => {
                                return `<li><a href="${item.link}" target="_blank" rel="noopener noreferrer">Top ${index + 1}: ${item.title}</a><p>${item.snippet}</p></li>`;
                            }).join('');

                            studioSelectedContent.innerHTML = `
                                <p class="studio-result-title">Top kết quả tìm kiếm thực từ Google (fallback)</p>
                                <p><a href="${directLink}" target="_blank" rel="noopener noreferrer">Mở trang kết quả Google gốc</a></p>
                                <ul class="studio-google-list">${htmlMirrorItems}</ul>
                            `;
                            return;
                        }
                    } catch (mirrorError) {
                        // Continue to final fallback UI below.
                    }

                    const cseOpened = tryOpenCseFallback(cseLink);

                    if (rawMessage.includes('missing-google-api-config')) {
                        friendlyMessage = 'Bạn chưa cấu hình Google API Key/CX.';
                    } else if (rawMessage.includes('API key not valid')) {
                        friendlyMessage = 'Google API Key không hợp lệ. Vui lòng tạo key mới.';
                    } else if (rawMessage.includes('has not been used in project') || rawMessage.includes('accessNotConfigured')) {
                        friendlyMessage = 'Custom Search API chưa được bật trong project Google Cloud.';
                    } else if (rawMessage.includes('Requests from referer') || rawMessage.includes('referer')) {
                        friendlyMessage = 'API key đang bị giới hạn domain (referer). Hãy tạm để Application restrictions = None để test.';
                    } else if (rawMessage.includes('The request is missing a valid API key')) {
                        friendlyMessage = 'Thiếu API key hợp lệ trong cấu hình.';
                    }

                    studioSelectedContent.innerHTML = `
                        <p><strong>${friendlyMessage}</strong></p>
                        <p>Chi tiết lỗi Google: ${rawMessage || 'Không rõ'}.</p>
                        <p>Kiểm tra nhanh:</p>
                        <p>1) Custom Search API đã Enable.</p>
                        <p>2) API restrictions chọn Custom Search API.</p>
                        <p>3) Application restrictions tạm để None khi test.</p>
                        <p>4) Google CX là Search engine ID đúng.</p>
                        ${cseOpened ? '<p>Đã tự động mở kết quả qua Google Programmable Search ở tab mới.</p>' : ''}
                        ${cseLink ? `<p><a href="${cseLink}" target="_blank" rel="noopener noreferrer">Mở kết quả thật qua Google Programmable Search (không bị chặn bởi JSON API)</a></p>` : ''}
                        <p><a href="${directLink}" target="_blank" rel="noopener noreferrer">Mở kết quả Google thực ngay bây giờ</a></p>
                    `;
                }
            };

            if (saveGoogleConfigBtn && googleApiKeyInput && googleCxInput && googleConfigStatus) {
                saveGoogleConfigBtn.addEventListener('click', function() {
                    const apiKey = googleApiKeyInput.value.trim();
                    const cx = googleCxInput.value.trim();

                    if (!apiKey || !cx) {
                        googleConfigStatus.textContent = 'Vui lòng nhập đầy đủ API Key và CX.';
                        return;
                    }

                    localStorage.setItem('googleApiKey', apiKey);
                    localStorage.setItem('googleCx', cx);
                    googleConfigStatus.textContent = 'Đã lưu cấu hình Google thành công.';

                    if (studioTemplateSelect && studioTemplateSelect.value === 'title') {
                        loadTitleResults();
                    }
                });
            }

            if (studioTemplateSelect && studioSelectedContent) {
                studioTemplateSelect.addEventListener('change', function() {
                    if (this.value !== 'title') {
                        studioSelectedContent.textContent = '';
                        return;
                    }
                    loadTitleResults();
                });

                // User requested: clicking "Thu vien mau" should immediately return real Google results.
                loadTitleResults();
            }

            return;
        }

        studioOutput.innerHTML = `
            <p class="studio-output-placeholder">Chọn mục "Thư viện mẫu" để hiển thị nội dung.</p>
        `;
    };

    sidebarCategoryLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();

            sidebarCategoryLinks.forEach(item => item.classList.remove('active'));
            this.classList.add('active');

            renderStudioContent(this.dataset.category);
        });
    });
}

    // Trend search button
    const searchBtn = document.getElementById('searchBtn');
    const searchResults = document.getElementById('searchResults');
    const resultsContent = document.getElementById('resultsContent');
    const trendSelect = document.querySelector('.trend-select');
    const trendInput = document.querySelector('.trend-input');

    // Function to fetch real search results - simplified version
    async function fetchRealResults(keyword) {
        const results = {};
        const searchQuery = encodeURIComponent(keyword + ' thai kỳ mẹ bầu');

        // YouTube - direct search links
        results.YouTube = [
            { title: `Video hướng dẫn "${keyword}"`, link: `https://www.youtube.com/results?search_query=${searchQuery}`, views: "Xem kết quả thực tế", duration: "YouTube Search" },
            { title: `Tips về "${keyword}"`, link: `https://www.youtube.com/results?search_query=${searchQuery}`, views: "Xem kết quả thực tế", duration: "YouTube Search" },
            { title: `Hướng dẫn "${keyword}"`, link: `https://www.youtube.com/results?search_query=${searchQuery}`, views: "Xem kết quả thực tế", duration: "YouTube Search" }
        ];

        // Google - direct search link
        results.Google = [{
            title: `Tìm kiếm Google: "${keyword}"`,
            link: `https://www.google.com/search?q=${searchQuery}`,
            views: "Kết quả tìm kiếm",
            engagement: "Google Search Results"
        }];

        // Other platforms - direct search links
        results.TikTok = [{
            title: `Tìm "${keyword}" trên TikTok`,
            link: `https://www.tiktok.com/search?q=${encodeURIComponent(keyword)}`,
            views: "Kết quả thực tế",
            engagement: "TikTok Search"
        }];

        results.Facebook = [{
            title: `Tìm "${keyword}" trên Facebook`,
            link: `https://www.facebook.com/search/posts?q=${encodeURIComponent(keyword)}`,
            views: "Kết quả thực tế",
            engagement: "Facebook Search"
        }];

        results.Douyin = [{
            title: `Tìm "${keyword}" trên Douyin`,
            link: `https://www.douyin.com/search/${encodeURIComponent(keyword)}`,
            views: "Kết quả thực tế",
            engagement: "Douyin Search"
        }];

        return results;
    }

    // Function to display results
    function displayResults(results, keyword) {
        let html = `<p><strong>Từ khóa:</strong> ${keyword}</p>`;
        const platforms = Object.keys(results);

        platforms.forEach(plat => {
            html += `<h4>${plat}</h4>`;
            results[plat].forEach(result => {
                html += `<div class="result-item">
                    <h5>${result.title}</h5>
                    <p>Views/Likes: ${result.views || 'N/A'} | Engagement: ${result.engagement || result.duration || 'N/A'}</p>
                    <a href="${result.link}" target="_blank">Xem chi tiết</a>
                </div>`;
            });
        });

        resultsContent.innerHTML = html;
        searchResults.style.display = 'block';
    }

    if (searchBtn) {
        searchBtn.addEventListener('click', async function() {
            const selectedKeyword = trendSelect.value;
            const customKeyword = trendInput.value.trim();
            
            // Ưu tiên custom keyword nếu có nhập, nếu không dùng dropdown
            const keyword = customKeyword || selectedKeyword;

            if (!keyword) {
                alert('Vui lòng chọn hoặc nhập từ khóa!');
                return;
            }

            console.log('Starting search for:', keyword);

            // Fetch real search results from platforms
            searchBtn.disabled = true;
            searchBtn.textContent = 'Đang tìm kiếm...';

            try {
                const results = await fetchRealResults(keyword);
                console.log('Results to display:', results);
                displayResults(results, keyword);
            } catch (error) {
                console.error('Search error:', error);
                // Fallback to generic links
                const allPlatforms = ["TikTok", "Douyin", "YouTube", "Facebook", "Google"];
                const genericResults = {};
                allPlatforms.forEach(plat => {
                    let searchLink = "#";
                    if (plat === "TikTok") searchLink = `https://www.tiktok.com/search?q=${encodeURIComponent(keyword)}`;
                    else if (plat === "YouTube") searchLink = `https://www.youtube.com/results?search_query=${encodeURIComponent(keyword)}`;
                    else if (plat === "Facebook") searchLink = `https://www.facebook.com/search/posts?q=${encodeURIComponent(keyword)}`;
                    else if (plat === "Google") searchLink = `https://www.google.com/search?q=${encodeURIComponent(keyword)}`;
                    else if (plat === "Douyin") searchLink = `https://www.douyin.com/search/${encodeURIComponent(keyword)}`;
                    genericResults[plat] = [{ title: `Tìm kiếm "${keyword}" trên ${plat}`, link: searchLink, views: "Kết quả thực tế", engagement: "Xem trên nền tảng" }];
                });
                displayResults(genericResults, keyword);
            } finally {
                searchBtn.disabled = false;
                searchBtn.textContent = 'Tìm Kiếm';
            }
        });
    }

    const addRowBtn = document.getElementById('addRowBtn');
    const calculateBtn = document.getElementById('calculateBtn');
    const exportBtn = document.getElementById('exportBtn');
    const reportTableBody = document.getElementById('reportTableBody');

    if (addRowBtn) {
        addRowBtn.addEventListener('click', function() {
            addNewRow();
        });
    }

    if (calculateBtn) {
        calculateBtn.addEventListener('click', function() {
            calculateSummary();
        });
    }

    if (exportBtn) {
        exportBtn.addEventListener('click', function() {
            exportReportData();
        });
    }

    // Add new row to report table
    function addNewRow() {
        const newRow = document.createElement('tr');
        newRow.className = 'data-row';
        newRow.innerHTML = `
            <td><input type="date" class="row-input" placeholder="Chọn ngày"></td>
            <td><input type="number" class="row-input" placeholder="Nhập số mess"></td>
            <td><input type="number" class="row-input" placeholder="Nhập số điện thoại"></td>
            <td><input type="number" class="row-input" placeholder="Nhập lịch hẹn"></td>
            <td><input type="number" class="row-input" placeholder="Tổng chi tiêu"></td>
            <td><input type="number" class="row-input" placeholder="Tổng doanh thu"></td>
            <td><button class="btn-delete" onclick="deleteRow(this)">🗑️</button></td>
        `;

        if (reportTableBody) {
            reportTableBody.appendChild(newRow);
            // Add event listeners to new inputs
            const inputs = newRow.querySelectorAll('.row-input');
            inputs.forEach(input => {
                input.addEventListener('change', calculateSummary);
                input.addEventListener('input', calculateSummary);
            });
        }
    }

    // Delete row function
    window.deleteRow = function(button) {
        button.closest('tr').remove();
        calculateSummary();
    };

    // Calculate summary statistics
    function calculateSummary() {
        console.log('calculateSummary called');
        const rows = document.querySelectorAll('.data-row');
        console.log('Found rows:', rows.length);
        let totalExpense = 0; // Tổng Chi Tiêu
        let totalRevenue = 0; // Tổng Doanh Thu
        let totalMessages = 0; // Số Mess

        rows.forEach((row, index) => {
            const inputs = row.querySelectorAll('.row-input');
            const rowTotalExpense = parseFloat((inputs[4] && inputs[4].value) || 0) || 0; // Tổng Chi Tiêu (index 4)
            const revenue = parseFloat((inputs[5] && inputs[5].value) || 0) || 0; // Tổng Doanh Thu (index 5)
            const messages = parseFloat((inputs[1] && inputs[1].value) || 0) || 0; // Số Mess (index 1)

            totalExpense += rowTotalExpense;
            totalRevenue += revenue;
            totalMessages += messages;
        });

        // Update summary display
        const totalExpenseEl = document.getElementById('totalExpense');
        const totalRevenueEl = document.getElementById('totalRevenue');
        const totalMessagesEl = document.getElementById('totalMessages');

        if (totalExpenseEl) {
            totalExpenseEl.textContent = totalExpense.toLocaleString('vi-VN') + ' VNĐ';
        }
        if (totalRevenueEl) {
            totalRevenueEl.textContent = totalRevenue.toLocaleString('vi-VN') + ' VNĐ';
        }
        if (totalMessagesEl) {
            totalMessagesEl.textContent = totalMessages.toString();
        }
    }

    // Export report data
    function exportReportData() {
        const rows = document.querySelectorAll('.data-row');
        let csv = 'Ngày,Số Mess,Số Điện Thoại,Lịch Hẹn,Tổng Chi Tiêu,Tổng Doanh Thu\n';

        rows.forEach(row => {
            const inputs = row.querySelectorAll('.row-input');
            const values = Array.from(inputs).map(input => input.value);
            csv += values.join(',') + '\n';
        });

        // Create download link
        const element = document.createElement('a');
        element.setAttribute('href', 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv));
        element.setAttribute('download', 'bao-cao-' + new Date().toISOString().split('T')[0] + '.csv');
        element.style.display = 'none';
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
    }

    // Initial summary calculation and add event listeners to existing inputs
    if (reportTableBody) {
        const allInputs = reportTableBody.querySelectorAll('.row-input');
        allInputs.forEach(input => {
            input.addEventListener('change', calculateSummary);
            input.addEventListener('input', calculateSummary);
        });

        // Delay calculation to ensure DOM is fully loaded
        setTimeout(() => {
            console.log('Calling calculateSummary after timeout');
            calculateSummary();
        }, 500);
    }

    try {
        const adsPerformanceChartCanvas = document.getElementById('adsPerformanceChart');
        const budgetInput = document.getElementById('budgetInput');
        const dailyBudgetInput = document.getElementById('dailyBudgetInput');
        const revenueInput = document.getElementById('revenueInput');
        const campaignInput = document.getElementById('campaignInput');

        const canInitDashboardChart = Boolean(
            adsPerformanceChartCanvas && budgetInput && dailyBudgetInput && revenueInput && campaignInput
        );

        const initDashboardChart = function() {
            if (!canInitDashboardChart || !window.Chart) {
                return false;
            }

            if (adsPerformanceChartCanvas.dataset.chartReady === '1') {
                return true;
            }

        const dashboardStorageKey = 'homeAdsDashboardInputs';
        const insightWeeklyStamp = document.getElementById('insightWeeklyStamp');

        const parseNumber = function(raw) {
            return Number(String(raw || '').replace(/[^0-9]/g, '')) || 0;
        };

        const formatWithSeparator = function(value) {
            return (Number(value) || 0).toLocaleString('vi-VN');
        };

        const clampCampaign = function(value) {
            const num = Number(value) || 1;
            return Math.max(1, Math.min(99, Math.round(num)));
        };

        const getWeekNumber = function(date) {
            const utcDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
            const day = utcDate.getUTCDay() || 7;
            utcDate.setUTCDate(utcDate.getUTCDate() + 4 - day);
            const yearStart = new Date(Date.UTC(utcDate.getUTCFullYear(), 0, 1));
            return Math.ceil((((utcDate - yearStart) / 86400000) + 1) / 7);
        };

        const buildLinkedValueSeries = function(value, days) {
            const valueInMillions = Number((((value || 0) / 1000000)).toFixed(2));
            return Array.from({ length: days }, () => valueInMillions);
        };

        const buildDefaultKpiSeries = function(totalValue, days) {
            return buildLinkedValueSeries(totalValue, days);
        };

        const labels = Array.from({ length: 30 }, (_, i) => String(i + 1));

        if (insightWeeklyStamp) {
            const now = new Date();
            const weekNumber = getWeekNumber(now);
            insightWeeklyStamp.textContent = 'Tuần ' + weekNumber + ' - ' + now.toLocaleDateString('vi-VN');
        }

        const chart = new Chart(adsPerformanceChartCanvas, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Chi phí hiện tại (triệu VNĐ)',
                        data: [],
                        tension: 0.35,
                        borderColor: '#ef5e7a',
                        backgroundColor: 'rgba(239, 94, 122, 0.10)',
                        pointBackgroundColor: '#db2777',
                        pointRadius: 2,
                        pointHoverRadius: 4,
                        fill: true
                    },
                    {
                        label: 'Doanh thu hiện tại (triệu VNĐ)',
                        data: [],
                        tension: 0.35,
                        borderColor: '#22c55e',
                        backgroundColor: 'rgba(34, 197, 94, 0.10)',
                        pointBackgroundColor: '#16a34a',
                        pointRadius: 2,
                        pointHoverRadius: 4,
                        fill: true
                    },
                    {
                        label: 'Doanh thu tổng KPI (triệu VNĐ)',
                        data: [],
                        tension: 0.35,
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.14)',
                        pointBackgroundColor: '#2563eb',
                        pointRadius: 2,
                        pointHoverRadius: 4,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            usePointStyle: true,
                            boxWidth: 10
                        }
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Ngày'
                        },
                        grid: {
                            color: 'rgba(122, 74, 98, 0.09)'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Chi phí / Doanh thu theo ngày (triệu VNĐ)'
                        },
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(122, 74, 98, 0.11)'
                        }
                    }
                }
            }
        });

        const savedState = JSON.parse(localStorage.getItem(dashboardStorageKey) || '{}');
        if (savedState.budget) {
            budgetInput.value = String(savedState.budget);
        }
        if (savedState.dailyBudget) {
            dailyBudgetInput.value = String(savedState.dailyBudget);
        }
        if (savedState.revenue) {
            revenueInput.value = String(savedState.revenue);
        }
        if (savedState.campaign) {
            campaignInput.value = String(savedState.campaign);
        }

        const updateDashboardChart = function() {
            const currentCost = parseNumber(budgetInput.value);
            const currentRevenue = parseNumber(dailyBudgetInput.value);
            const totalKpiRevenue = parseNumber(revenueInput.value);
            const campaignCount = clampCampaign(campaignInput.value);

            setRoasAlertContext(currentCost, currentRevenue);

            budgetInput.value = formatWithSeparator(currentCost);
            dailyBudgetInput.value = formatWithSeparator(currentRevenue);
            revenueInput.value = formatWithSeparator(totalKpiRevenue);
            campaignInput.value = String(campaignCount);

            localStorage.setItem(dashboardStorageKey, JSON.stringify({
                budget: currentCost,
                dailyBudget: currentRevenue,
                revenue: totalKpiRevenue,
                campaign: campaignCount
            }));

            chart.data.datasets[0].data = buildLinkedValueSeries(currentCost, 30);
            chart.data.datasets[1].data = buildLinkedValueSeries(currentRevenue, 30);
            chart.data.datasets[2].data = buildDefaultKpiSeries(totalKpiRevenue, 30);
            chart.update();
        };

        budgetInput.addEventListener('input', updateDashboardChart);
        dailyBudgetInput.addEventListener('input', updateDashboardChart);
        revenueInput.addEventListener('input', updateDashboardChart);
        campaignInput.addEventListener('input', updateDashboardChart);

        updateDashboardChart();
        hydrateHomeAlerts();
        adsPerformanceChartCanvas.dataset.chartReady = '1';
        return true;
    };

        if (canInitDashboardChart && !initDashboardChart()) {
            const fallbackChartScript = document.createElement('script');
            fallbackChartScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.3/chart.umd.min.js';
            fallbackChartScript.defer = true;

            fallbackChartScript.onload = function() {
                if (!initDashboardChart()) {
                    const chartPanel = adsPerformanceChartCanvas.closest('.chart-panel');
                    if (chartPanel) {
                        chartPanel.innerHTML = '<p style="margin:0;padding:1rem;color:#7a2e45;font-weight:700;">Không thể tải thư viện biểu đồ. Vui lòng tải lại trang (Ctrl+F5).</p>';
                    }
                }
            };

            fallbackChartScript.onerror = function() {
                const chartPanel = adsPerformanceChartCanvas.closest('.chart-panel');
                if (chartPanel) {
                    chartPanel.innerHTML = '<p style="margin:0;padding:1rem;color:#7a2e45;font-weight:700;">Không thể kết nối đến Chart.js. Vui lòng kiểm tra mạng hoặc thử lại sau.</p>';
                }
            };

            document.head.appendChild(fallbackChartScript);
        }
    } catch (chartError) {
        const chartCanvas = document.getElementById('adsPerformanceChart');
        const chartPanel = chartCanvas ? chartCanvas.closest('.chart-panel') : null;
        if (chartPanel) {
            chartPanel.innerHTML = '<p style="margin:0;padding:1rem;color:#7a2e45;font-weight:700;">Biểu đồ tạm thời không khả dụng. Các chức năng khác vẫn hoạt động bình thường.</p>';
        }
        console.error('Dashboard chart init failed:', chartError);
    }

    const checklistContainer = document.getElementById('checklistContainer');
    const addChecklistItemBtn = document.getElementById('addChecklistItemBtn');

    if (checklistContainer && addChecklistItemBtn) {
        const checklistStorageKey = 'homeChecklistItems';

        const createChecklistRow = function(item) {
            const row = document.createElement('label');
            row.className = 'checklist-row';
            row.innerHTML = `
                <input class="checklist-checkbox" type="checkbox" ${item.checked ? 'checked' : ''}>
                <input class="checklist-text" type="text" value="${(item.text || '').replace(/"/g, '&quot;')}" placeholder="Nhập nội dung checklist">
                <input class="checklist-due" type="date" value="${item.dueDate || ''}" aria-label="Hạn hoàn thành">
            `;

            const checkbox = row.querySelector('.checklist-checkbox');
            const textInput = row.querySelector('.checklist-text');
            const dueInput = row.querySelector('.checklist-due');

            const syncCheckedStyle = function() {
                row.classList.toggle('is-checked', checkbox.checked);
            };

            checkbox.addEventListener('change', function() {
                syncCheckedStyle();
                saveChecklist();
            });

            textInput.addEventListener('input', saveChecklist);
            dueInput.addEventListener('change', saveChecklist);
            syncCheckedStyle();
            return row;
        };

        var saveChecklist = function() {
            const allRows = checklistContainer.querySelectorAll('.checklist-row');
            const data = Array.from(allRows).map(function(row) {
                const checkboxEl = row.querySelector('.checklist-checkbox');
                const textEl = row.querySelector('.checklist-text');
                const dueEl = row.querySelector('.checklist-due');
                return {
                    checked: !!(checkboxEl && checkboxEl.checked),
                    text: (textEl && textEl.value) || '',
                    dueDate: (dueEl && dueEl.value) || ''
                };
            });

            localStorage.setItem(checklistStorageKey, JSON.stringify(data));
            setChecklistOverdueContext(data);
        };

        const savedChecklist = JSON.parse(localStorage.getItem(checklistStorageKey) || 'null');
        if (Array.isArray(savedChecklist) && savedChecklist.length) {
            checklistContainer.innerHTML = '';
            savedChecklist.forEach(function(item) {
                checklistContainer.appendChild(createChecklistRow(item));
            });
        } else {
            checklistContainer.querySelectorAll('.checklist-row').forEach(function(row) {
                const checkbox = row.querySelector('.checklist-checkbox');
                const textInput = row.querySelector('.checklist-text');
                const dueInput = row.querySelector('.checklist-due');

                const syncCheckedStyle = function() {
                    row.classList.toggle('is-checked', checkbox.checked);
                };

                checkbox.addEventListener('change', function() {
                    syncCheckedStyle();
                    saveChecklist();
                });
                textInput.addEventListener('input', saveChecklist);
                if (dueInput) {
                    dueInput.addEventListener('change', saveChecklist);
                }
                syncCheckedStyle();
            });

            saveChecklist();
        }

        addChecklistItemBtn.addEventListener('click', function() {
            const row = createChecklistRow({ checked: false, text: '' });
            checklistContainer.appendChild(row);
            const input = row.querySelector('.checklist-text');
            if (input) {
                input.focus();
            }
            saveChecklist();
        });
    }

// Account and authorization module (localStorage based)
(function() {
    const ACCOUNTS_KEY = 'ma_accounts_v1';
    const BACKUPS_KEY = 'ma_account_backups_v1';
    const SESSION_KEY = 'ma_session_v1';
    const OWNER_ID_KEY = 'ma_owner_id_v1';

    const parseJson = function(key, fallback) {
        try {
            const raw = localStorage.getItem(key);
            return raw ? JSON.parse(raw) : fallback;
        } catch (e) {
            return fallback;
        }
    };

    const getAccounts = function() {
        return parseJson(ACCOUNTS_KEY, []);
    };

    const saveAccounts = function(accounts) {
        localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
    };

    const getBackups = function() {
        return parseJson(BACKUPS_KEY, []);
    };

    const saveBackups = function(backups) {
        localStorage.setItem(BACKUPS_KEY, JSON.stringify(backups));
    };

    const getSession = function() {
        return parseJson(SESSION_KEY, null);
    };

    const setSession = function(session) {
        localStorage.setItem(SESSION_KEY, JSON.stringify(session));
    };

    const clearSession = function() {
        localStorage.removeItem(SESSION_KEY);
    };

    const getOwnerId = function() {
        return localStorage.getItem(OWNER_ID_KEY) || '';
    };

    const setOwnerId = function(userId) {
        if (!userId) {
            return;
        }
        localStorage.setItem(OWNER_ID_KEY, userId);
    };

    const ensureOwnerBinding = function() {
        const users = getAccounts();
        const boundOwnerId = getOwnerId();

        if (boundOwnerId) {
            const owner = users.find(function(u) {
                return u.id === boundOwnerId && u.role === 'superadmin' && u.status === 'active';
            });
            if (owner) {
                return owner.id;
            }
        }

        const fallbackOwner = users.find(function(u) {
            return u.role === 'superadmin' && u.status === 'active';
        });

        if (!fallbackOwner) {
            return '';
        }

        setOwnerId(fallbackOwner.id);
        return fallbackOwner.id;
    };

    const setSiteLocked = function(locked) {
        if (!document.body) {
            return;
        }
        document.body.classList.toggle('auth-site-locked', !!locked);
    };

    const getCurrentUser = function() {
        const session = getSession();
        if (!session || !session.userId) {
            return null;
        }
        const users = getAccounts();
        return users.find(function(u) {
            return u.id === session.userId;
        }) || null;
    };

    const addAuthStyles = function() {
        if (document.getElementById('authStyles')) {
            return;
        }
        const style = document.createElement('style');
        style.id = 'authStyles';
        style.textContent = '' +
            '.auth-overlay{position:fixed;inset:0;background:#fff;display:flex;align-items:center;justify-content:center;z-index:99999;padding:1rem;}' +
            '.auth-modal{width:min(460px,96vw);background:#fff;border-radius:18px;box-shadow:0 18px 50px rgba(0,0,0,.3);padding:1rem 1.05rem;}' +
            '.auth-title{margin:0 0 .35rem;color:#7a2e45;font-size:1.2rem;font-weight:800;}' +
            '.auth-sub{margin:0 0 .8rem;color:#7e6d75;font-size:.9rem;}' +
            '.auth-grid{display:grid;gap:.55rem;}' +
            '.auth-input{width:100%;border:1px solid #e8cbd7;border-radius:10px;padding:.62rem .72rem;font-size:.92rem;font-family:inherit;outline:none;}' +
            '.auth-input:focus{border-color:#c7517c;box-shadow:0 0 0 3px rgba(199,81,124,.15);}' +
            '.auth-actions{display:flex;gap:.5rem;margin-top:.75rem;}' +
            '.auth-btn{flex:1;border:none;border-radius:10px;padding:.62rem .82rem;font-weight:700;cursor:pointer;}' +
            '.auth-btn.primary{background:linear-gradient(135deg,#c7517c,#a93c63);color:#fff;}' +
            '.auth-btn.gray{background:#f5f2f4;color:#6d5a62;border:1px solid #e5d9de;}' +
            '.auth-error{margin-top:.55rem;color:#dc2626;font-weight:700;font-size:.86rem;min-height:1.15rem;}' +
            '.auth-badge{display:inline-flex;align-items:center;gap:.45rem;padding:.35rem .65rem;border-radius:999px;background:#fff0f5;color:#7a2e45;border:1px solid #f1c6d8;font-weight:700;font-size:.82rem;}' +
            '.auth-badge button{border:none;background:#c7517c;color:#fff;border-radius:999px;padding:.2rem .55rem;cursor:pointer;font-size:.75rem;font-weight:700;}' +
            '.admin-note{margin:.5rem 0;color:#7f2d4a;font-weight:700;font-size:.9rem;}' +
            '.admin-denied{padding:1rem;border:1px dashed #e9c8d6;border-radius:12px;background:#fff7fb;color:#7f2d4a;font-weight:700;}' +
            '.account-status.pending{background:#fef9c3;color:#854d0e;border:1px solid #fde68a;padding:.18rem .48rem;border-radius:999px;display:inline-block;}' +
            'body.auth-site-locked > *:not(#authOverlay){display:none !important;}';
        document.head.appendChild(style);
    };

    const ensureOwnerExists = function() {
        const users = getAccounts();
        const hasOwner = users.some(function(u) {
            return u.role === 'superadmin' && u.status === 'active';
        });

        if (hasOwner) {
            ensureOwnerBinding();
        }

        return hasOwner;
    };

    const ensureDemoStaffAccounts = function() {
        const users = getAccounts();
        const demoAccounts = [
            {
                username: 'nhansu01',
                password: '123456',
                fullName: 'Nhân sự 01',
                phone: '0900000001'
            },
            {
                username: 'nhansu02',
                password: '123456',
                fullName: 'Nhân sự 02',
                phone: '0900000002'
            }
        ];

        let changed = false;

        demoAccounts.forEach(function(acc) {
            const exists = users.some(function(u) {
                return String(u.username || '').toLowerCase() === acc.username.toLowerCase();
            });

            if (!exists) {
                users.push({
                    id: 'u_' + Date.now() + '_' + acc.username,
                    username: acc.username,
                    password: acc.password,
                    fullName: acc.fullName,
                    phone: acc.phone,
                    role: 'staff',
                    status: 'active',
                    data: {},
                    createdAt: Date.now(),
                    updatedAt: Date.now()
                });
                changed = true;
            }
        });

        if (changed) {
            saveAccounts(users);
        }
    };

    const mountAuthBadge = function(user) {
        const navLinks = document.querySelector('header nav .nav-links');
        if (!navLinks) {
            return;
        }

        let adminNavItem = document.getElementById('adminPanelNav');
        if (user && user.role === 'superadmin') {
            if (!adminNavItem) {
                adminNavItem = document.createElement('li');
                adminNavItem.id = 'adminPanelNav';
                navLinks.appendChild(adminNavItem);
            }
            adminNavItem.innerHTML = '<a href="./content.html">Quản trị tài khoản</a>';
        } else if (adminNavItem) {
            adminNavItem.remove();
        }

        let host = document.getElementById('authNavHost');
        if (!host) {
            host = document.createElement('li');
            host.id = 'authNavHost';
            navLinks.appendChild(host);
        }

        if (!user) {
            host.innerHTML = '<button id="openLoginModal" class="auth-badge" style="cursor:pointer;">Đăng nhập</button>';
            const loginBtn = document.getElementById('openLoginModal');
            if (loginBtn) {
                loginBtn.addEventListener('click', function() {
                    showAuthModal('choice');
                });
            }
            return;
        }

        host.innerHTML = '<span class="auth-badge">' +
            (user.fullName || user.username) +
            ' (' + (user.role === 'superadmin' ? 'Quản trị cao nhất' : 'Nhân sự') + ')' +
            '<button id="logoutBtn" type="button">Thoát</button></span>';

        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', function() {
                clearSession();
                location.reload();
            });
        }
    };

    const hideAuthModal = function() {
        const overlay = document.getElementById('authOverlay');
        if (overlay) {
            overlay.remove();
        }
    };

    const showAuthModal = function(mode) {
        addAuthStyles();
        hideAuthModal();

        const setupMode = mode === 'setup-owner';
        const registerMode = mode === 'register';
        const choiceMode = mode === 'choice';
        const overlay = document.createElement('div');
        overlay.className = 'auth-overlay';
        overlay.id = 'authOverlay';

        overlay.innerHTML = setupMode ? (
            '<div class="auth-modal">' +
                '<h3 class="auth-title">Tạo tài khoản quản trị cao nhất</h3>' +
                '<p class="auth-sub">Thiết lập tài khoản của bạn để quản lý toàn bộ nhân sự.</p>' +
                '<div class="auth-grid">' +
                    '<input id="ownerFullName" class="auth-input" type="text" placeholder="Họ và tên">' +
                    '<input id="ownerUsername" class="auth-input" type="text" placeholder="Tên đăng nhập">' +
                    '<input id="ownerPassword" class="auth-input" type="password" placeholder="Mật khẩu">' +
                    '<input id="ownerPassword2" class="auth-input" type="password" placeholder="Nhập lại mật khẩu">' +
                '</div>' +
                '<div class="auth-actions"><button id="ownerCreateBtn" class="auth-btn primary" type="button">Tạo tài khoản</button></div>' +
                '<div id="authError" class="auth-error"></div>' +
            '</div>'
        ) : registerMode ? (
            '<div class="auth-modal">' +
                '<h3 class="auth-title">Đăng ký tài khoản</h3>' +
                '<p class="auth-sub">Sau khi đăng ký, tài khoản cần quản trị cao nhất duyệt trước khi đăng nhập.</p>' +
                '<div class="auth-grid">' +
                    '<input id="registerFullName" class="auth-input" type="text" placeholder="Họ và tên">' +
                    '<input id="registerPhone" class="auth-input" type="text" placeholder="Số điện thoại">' +
                    '<input id="registerUsername" class="auth-input" type="text" placeholder="Tên đăng nhập">' +
                    '<input id="registerPassword" class="auth-input" type="password" placeholder="Mật khẩu">' +
                    '<input id="registerPassword2" class="auth-input" type="password" placeholder="Nhập lại mật khẩu">' +
                '</div>' +
                '<div class="auth-actions">' +
                    '<button id="registerBtn" class="auth-btn primary" type="button">Tạo tài khoản</button>' +
                    '<button id="backToLoginBtn" class="auth-btn gray" type="button">Về đăng nhập</button>' +
                '</div>' +
                '<div id="authError" class="auth-error"></div>' +
            '</div>'
        ) : choiceMode ? (
            '<div class="auth-modal">' +
                '<h3 class="auth-title">Chào mừng bạn</h3>' +
                '<p class="auth-sub">Vui lòng chọn một thao tác để tiếp tục vào hệ thống.</p>' +
                '<div class="auth-actions">' +
                    '<button id="goLoginBtn" class="auth-btn primary" type="button">Đăng nhập</button>' +
                    '<button id="goRegisterBtn" class="auth-btn gray" type="button">Đăng ký</button>' +
                '</div>' +
                '<div id="authError" class="auth-error"></div>' +
            '</div>'
        ) : (
            '<div class="auth-modal">' +
                '<h3 class="auth-title">Đăng nhập hệ thống</h3>' +
                '<p class="auth-sub">Bạn có thể chọn Đăng nhập hoặc Đăng ký để tiếp tục.</p>' +
                '<div class="auth-grid">' +
                    '<input id="loginUsername" class="auth-input" type="text" placeholder="Tên đăng nhập">' +
                    '<input id="loginPassword" class="auth-input" type="password" placeholder="Mật khẩu">' +
                '</div>' +
                '<div class="auth-actions">' +
                    '<button id="loginBtn" class="auth-btn primary" type="button">Đăng nhập</button>' +
                    '<button id="openRegisterBtn" class="auth-btn gray" type="button">Đăng ký</button>' +
                '</div>' +
                '<div id="authError" class="auth-error"></div>' +
            '</div>'
        );

        document.body.appendChild(overlay);

        const errorEl = document.getElementById('authError');

        if (setupMode) {
            const createBtn = document.getElementById('ownerCreateBtn');
            if (createBtn) {
                createBtn.addEventListener('click', function() {
                    const fullName = (document.getElementById('ownerFullName').value || '').trim();
                    const username = (document.getElementById('ownerUsername').value || '').trim();
                    const password = (document.getElementById('ownerPassword').value || '').trim();
                    const password2 = (document.getElementById('ownerPassword2').value || '').trim();

                    if (!fullName || !username || !password || !password2) {
                        errorEl.textContent = 'Vui lòng nhập đầy đủ thông tin.';
                        return;
                    }
                    if (password !== password2) {
                        errorEl.textContent = 'Mật khẩu nhập lại không khớp.';
                        return;
                    }

                    const users = getAccounts();
                    if (users.some(function(u) { return u.username.toLowerCase() === username.toLowerCase(); })) {
                        errorEl.textContent = 'Tên đăng nhập đã tồn tại.';
                        return;
                    }

                    const owner = {
                        id: 'u_' + Date.now(),
                        username: username,
                        password: password,
                        fullName: fullName,
                        role: 'superadmin',
                        status: 'active',
                        data: {},
                        createdAt: Date.now(),
                        updatedAt: Date.now()
                    };

                    users.push(owner);
                    saveAccounts(users);
                    setOwnerId(owner.id);
                    setSession({ userId: owner.id, at: Date.now() });
                    hideAuthModal();
                    location.reload();
                });
            }
            return;
        }

        if (choiceMode) {
            const goLoginBtn = document.getElementById('goLoginBtn');
            const goRegisterBtn = document.getElementById('goRegisterBtn');

            if (goLoginBtn) {
                goLoginBtn.addEventListener('click', function() {
                    showAuthModal('login');
                });
            }

            if (goRegisterBtn) {
                goRegisterBtn.addEventListener('click', function() {
                    showAuthModal('register');
                });
            }

            return;
        }

        if (registerMode) {
            const registerBtn = document.getElementById('registerBtn');
            const backToLoginBtn = document.getElementById('backToLoginBtn');

            if (backToLoginBtn) {
                backToLoginBtn.addEventListener('click', function() {
                    showAuthModal('login');
                });
            }

            if (registerBtn) {
                registerBtn.addEventListener('click', function() {
                    const fullName = (document.getElementById('registerFullName').value || '').trim();
                    const phone = (document.getElementById('registerPhone').value || '').trim();
                    const username = (document.getElementById('registerUsername').value || '').trim();
                    const password = (document.getElementById('registerPassword').value || '').trim();
                    const password2 = (document.getElementById('registerPassword2').value || '').trim();

                    if (!fullName || !phone || !username || !password || !password2) {
                        errorEl.textContent = 'Vui lòng nhập đầy đủ thông tin.';
                        return;
                    }

                    if (password !== password2) {
                        errorEl.textContent = 'Mật khẩu nhập lại không khớp.';
                        return;
                    }

                    const users = getAccounts();
                    if (users.some(function(u) { return u.username.toLowerCase() === username.toLowerCase(); })) {
                        errorEl.textContent = 'Tên đăng nhập đã tồn tại.';
                        return;
                    }

                    users.push({
                        id: 'u_' + Date.now(),
                        username: username,
                        password: password,
                        fullName: fullName,
                        phone: phone,
                        role: 'staff',
                        status: 'pending',
                        data: {},
                        createdAt: Date.now(),
                        updatedAt: Date.now()
                    });

                    saveAccounts(users);
                    sessionStorage.setItem('ma_prefill_username', username);
                    sessionStorage.setItem('ma_auth_info', 'Đăng ký thành công. Tài khoản đang chờ duyệt từ quản trị cao nhất.');
                    showAuthModal('login');
                });
            }
            return;
        }

        const loginBtn = document.getElementById('loginBtn');
        const openRegisterBtn = document.getElementById('openRegisterBtn');
        const loginUsernameInput = document.getElementById('loginUsername');

        const prefillUsername = sessionStorage.getItem('ma_prefill_username');
        if (loginUsernameInput && prefillUsername) {
            loginUsernameInput.value = prefillUsername;
            sessionStorage.removeItem('ma_prefill_username');
        }

        const infoMessage = sessionStorage.getItem('ma_auth_info');
        if (errorEl && infoMessage) {
            errorEl.style.color = '#15803d';
            errorEl.textContent = infoMessage;
            sessionStorage.removeItem('ma_auth_info');
        }

        if (openRegisterBtn) {
            openRegisterBtn.addEventListener('click', function() {
                showAuthModal('register');
            });
        }

        if (loginBtn) {
            loginBtn.addEventListener('click', function() {
                const username = (document.getElementById('loginUsername').value || '').trim().toLowerCase();
                const password = (document.getElementById('loginPassword').value || '').trim();

                const user = getAccounts().find(function(u) {
                    return u.username.toLowerCase() === username && u.password === password;
                });

                if (!user) {
                    errorEl.style.color = '#dc2626';
                    errorEl.textContent = 'Sai tên đăng nhập hoặc mật khẩu.';
                    return;
                }

                if (user.status === 'pending') {
                    errorEl.style.color = '#dc2626';
                    errorEl.textContent = 'Tài khoản đang chờ quản trị cao nhất duyệt.';
                    return;
                }

                if (user.status !== 'active') {
                    errorEl.style.color = '#dc2626';
                    errorEl.textContent = 'Tài khoản đang bị vô hiệu hóa hoặc đã xóa.';
                    return;
                }

                setSession({ userId: user.id, at: Date.now() });
                setSiteLocked(false);
                hideAuthModal();
                location.reload();
            });
        }
    };

    const initAccountManager = function(currentUser) {
        const root = document.getElementById('accountManagerRoot');
        if (!root) {
            return;
        }

        const filterState = {
            keyword: '',
            status: 'all',
            role: 'all'
        };

        if (!currentUser) {
            root.innerHTML = '<div class="admin-denied">Bạn chưa đăng nhập. Vui lòng đăng nhập để sử dụng trang quản trị tài khoản.</div>';
            return;
        }

        if (currentUser.role !== 'superadmin') {
            root.innerHTML = '<div class="admin-denied">Bạn không có quyền truy cập khu vực này. Chỉ tài khoản quản trị cao nhất mới được quản lý nhân sự.</div>';
            return;
        }

        const ownerId = ensureOwnerBinding();
        const canEditRoles = !!ownerId && currentUser.id === ownerId;

        const render = function() {
            const users = getAccounts();
            const backups = getBackups();
            const normalizedKeyword = String(filterState.keyword || '').trim().toLowerCase();

            const filteredUsers = users.filter(function(u) {
                if (filterState.status !== 'all' && (u.status || '') !== filterState.status) {
                    return false;
                }

                if (filterState.role !== 'all' && (u.role || '') !== filterState.role) {
                    return false;
                }

                if (!normalizedKeyword) {
                    return true;
                }

                const source = [
                    u.fullName || '',
                    u.username || '',
                    u.phone || ''
                ].join(' ').toLowerCase();

                return source.includes(normalizedKeyword);
            });

            const userRows = filteredUsers.map(function(u) {
                const statusClass = u.status === 'active' ? 'active' : (u.status === 'pending' ? 'pending' : 'deleted');
                const isSelf = u.id === currentUser.id;
                const statusLabel = u.status === 'active' ? 'Hoạt động' : (u.status === 'pending' ? 'Chờ duyệt' : 'Đã xóa');
                const roleEditable = canEditRoles && u.status !== 'deleted';
                const roleSelectHtml = '<select class="account-input account-role-select" data-role-id="' + u.id + '" ' + (roleEditable ? '' : 'disabled') + '>' +
                    '<option value="superadmin" ' + (u.role === 'superadmin' ? 'selected' : '') + '>Quản trị cao nhất</option>' +
                    '<option value="staff" ' + (u.role !== 'superadmin' ? 'selected' : '') + '>Nhân sự</option>' +
                '</select>';
                const actionHtml = u.status === 'active'
                    ? '<button class="account-btn warn" data-action="delete" data-id="' + u.id + '" ' + (isSelf ? 'disabled' : '') + '>Xóa</button>'
                    : (u.status === 'pending'
                        ? '<button class="account-btn primary" data-action="approve" data-id="' + u.id + '">Duyệt</button><button class="account-btn warn" data-action="delete" data-id="' + u.id + '">Từ chối</button>'
                        : '<button class="account-btn gray" data-action="restore" data-id="' + u.id + '">Khôi phục</button>');
                return '<tr>' +
                    '<td>' + (u.fullName || '-') + '</td>' +
                    '<td>' + u.username + '</td>' +
                    '<td>' + (u.phone || '-') + '</td>' +
                    '<td>' + roleSelectHtml + '</td>' +
                    '<td><span class="account-status ' + statusClass + '">' + statusLabel + '</span></td>' +
                    '<td>' + new Date(u.createdAt || Date.now()).toLocaleString('vi-VN') + '</td>' +
                    '<td><div class="account-actions">' +
                        '<button class="account-btn gray" data-action="save-role" data-id="' + u.id + '" ' + (roleEditable ? '' : 'disabled') + '>Lưu vai trò</button>' +
                        actionHtml +
                        '<button class="account-btn gray" data-action="backup" data-id="' + u.id + '">Sao lưu dữ liệu</button>' +
                        '<button class="account-btn gray" data-action="restore-data" data-id="' + u.id + '">Khôi phục dữ liệu</button>' +
                    '</div></td>' +
                '</tr>';
            }).join('');

            const backupRows = backups.slice(0, 20).map(function(b) {
                return '<tr>' +
                    '<td>' + (b.userName || '-') + '</td>' +
                    '<td>' + new Date(b.createdAt).toLocaleString('vi-VN') + '</td>' +
                    '<td>' +
                        '<button class="account-btn gray" data-action="apply-backup" data-backup="' + b.id + '">Khôi phục bản sao lưu</button>' +
                    '</td>' +
                '</tr>';
            }).join('');

            root.innerHTML = '' +
                '<div class="account-card">' +
                    '<h3 class="account-title" style="font-size:1.05rem;">Thêm tài khoản nhân sự</h3>' +
                    '<div class="account-grid">' +
                        '<input id="staffFullName" class="account-input" type="text" placeholder="Họ và tên nhân sự">' +
                        '<input id="staffPhone" class="account-input" type="text" placeholder="Số điện thoại">' +
                        '<input id="staffUsername" class="account-input" type="text" placeholder="Tên đăng nhập">' +
                        '<input id="staffPassword" class="account-input" type="password" placeholder="Mật khẩu">' +
                    '</div>' +
                    '<div style="margin-top:.7rem;display:flex;gap:.5rem;align-items:center;">' +
                        '<button id="addStaffBtn" class="account-btn primary" type="button">Thêm tài khoản</button>' +
                        '<span id="accountActionMsg" class="admin-note"></span>' +
                    '</div>' +
                '</div>' +
                '<div class="account-card">' +
                    '<h3 class="account-title" style="font-size:1.05rem;">Danh sách tài khoản</h3>' +
                    '<div style="display:grid;grid-template-columns:minmax(190px,1.3fr) minmax(130px,.9fr) minmax(130px,.9fr) auto auto;gap:.55rem;align-items:center;margin-bottom:.75rem;">' +
                        '<input id="accountFilterKeyword" class="account-input" type="text" placeholder="Tìm theo tên, đăng nhập, số điện thoại">' +
                        '<select id="accountFilterStatus" class="account-input" aria-label="Lọc trạng thái">' +
                            '<option value="all">Tất cả trạng thái</option>' +
                            '<option value="active">Hoạt động</option>' +
                            '<option value="pending">Chờ duyệt</option>' +
                            '<option value="deleted">Đã xóa</option>' +
                        '</select>' +
                        '<select id="accountFilterRole" class="account-input" aria-label="Lọc vai trò">' +
                            '<option value="all">Tất cả vai trò</option>' +
                            '<option value="superadmin">Quản trị cao nhất</option>' +
                            '<option value="staff">Nhân sự</option>' +
                        '</select>' +
                        '<button id="applyAccountFilterBtn" class="account-btn gray" type="button">Lọc</button>' +
                        '<button id="clearAccountFilterBtn" class="account-btn gray" type="button">Xóa lọc</button>' +
                    '</div>' +
                    '<div class="account-table-wrap">' +
                        '<table class="account-table">' +
                            '<thead><tr><th>Họ tên</th><th>Tên đăng nhập</th><th>Số điện thoại</th><th>Vai trò</th><th>Trạng thái</th><th>Ngày tạo</th><th>Thao tác</th></tr></thead>' +
                            '<tbody>' + (userRows || '<tr><td colspan="7" class="account-empty">Không có tài khoản phù hợp bộ lọc.</td></tr>') + '</tbody>' +
                        '</table>' +
                    '</div>' +
                '</div>' +
                '<div class="account-card">' +
                    '<h3 class="account-title" style="font-size:1.05rem;">Bản sao lưu dữ liệu tài khoản</h3>' +
                    '<div class="account-table-wrap">' +
                        '<table class="account-table">' +
                            '<thead><tr><th>Tài khoản</th><th>Thời gian</th><th>Thao tác</th></tr></thead>' +
                            '<tbody>' + (backupRows || '<tr><td colspan="3" class="account-empty">Chưa có bản sao lưu.</td></tr>') + '</tbody>' +
                        '</table>' +
                    '</div>' +
                '</div>';

            const msg = function(text, good) {
                const el = document.getElementById('accountActionMsg');
                if (!el) {
                    return;
                }
                el.textContent = text;
                el.style.color = good ? '#15803d' : '#b91c1c';
            };

            const addStaffBtn = document.getElementById('addStaffBtn');
            if (addStaffBtn) {
                addStaffBtn.addEventListener('click', function() {
                    const fullName = (document.getElementById('staffFullName').value || '').trim();
                    const phone = (document.getElementById('staffPhone').value || '').trim();
                    const username = (document.getElementById('staffUsername').value || '').trim();
                    const password = (document.getElementById('staffPassword').value || '').trim();

                    if (!fullName || !phone || !username || !password) {
                        msg('Vui lòng nhập đầy đủ thông tin nhân sự.', false);
                        return;
                    }

                    const list = getAccounts();
                    if (list.some(function(u) { return u.username.toLowerCase() === username.toLowerCase(); })) {
                        msg('Tên đăng nhập đã tồn tại.', false);
                        return;
                    }

                    list.push({
                        id: 'u_' + Date.now(),
                        username: username,
                        password: password,
                        fullName: fullName,
                        phone: phone,
                        role: 'staff',
                        status: 'active',
                        data: {},
                        createdAt: Date.now(),
                        updatedAt: Date.now()
                    });

                    saveAccounts(list);
                    msg('Đã thêm tài khoản nhân sự thành công.', true);
                    render();
                });
            }

            const accountFilterKeyword = document.getElementById('accountFilterKeyword');
            const accountFilterStatus = document.getElementById('accountFilterStatus');
            const accountFilterRole = document.getElementById('accountFilterRole');
            const applyAccountFilterBtn = document.getElementById('applyAccountFilterBtn');
            const clearAccountFilterBtn = document.getElementById('clearAccountFilterBtn');

            if (accountFilterKeyword) {
                accountFilterKeyword.value = filterState.keyword;
                accountFilterKeyword.addEventListener('keydown', function(evt) {
                    if (evt.key === 'Enter') {
                        evt.preventDefault();
                        filterState.keyword = this.value || '';
                        filterState.status = accountFilterStatus ? accountFilterStatus.value : 'all';
                        filterState.role = accountFilterRole ? accountFilterRole.value : 'all';
                        render();
                    }
                });
            }

            if (accountFilterStatus) {
                accountFilterStatus.value = filterState.status;
            }

            if (accountFilterRole) {
                accountFilterRole.value = filterState.role;
            }

            if (applyAccountFilterBtn) {
                applyAccountFilterBtn.addEventListener('click', function() {
                    filterState.keyword = accountFilterKeyword ? accountFilterKeyword.value : '';
                    filterState.status = accountFilterStatus ? accountFilterStatus.value : 'all';
                    filterState.role = accountFilterRole ? accountFilterRole.value : 'all';
                    render();
                });
            }

            if (clearAccountFilterBtn) {
                clearAccountFilterBtn.addEventListener('click', function() {
                    filterState.keyword = '';
                    filterState.status = 'all';
                    filterState.role = 'all';
                    render();
                });
            }

            root.querySelectorAll('[data-action]').forEach(function(btn) {
                btn.addEventListener('click', function() {
                    const action = this.dataset.action;
                    const userId = this.dataset.id;

                    if (action === 'apply-backup') {
                        const backupId = this.dataset.backup;
                        const allBackups = getBackups();
                        const backup = allBackups.find(function(b) { return b.id === backupId; });
                        if (!backup) {
                            return;
                        }
                        const list = getAccounts();
                        const idx = list.findIndex(function(u) { return u.id === backup.userId; });
                        if (idx < 0) {
                            msg('Không tìm thấy tài khoản để khôi phục bản sao lưu.', false);
                            return;
                        }
                        list[idx].data = backup.dataSnapshot || {};
                        list[idx].updatedAt = Date.now();
                        saveAccounts(list);
                        msg('Đã khôi phục dữ liệu từ bản sao lưu.', true);
                        render();
                        return;
                    }

                    if (action === 'save-role') {
                        if (!canEditRoles) {
                            msg('Chỉ tài khoản quản trị cao nhất chính mới có quyền chỉnh sửa vai trò.', false);
                            return;
                        }

                        if (!userId) {
                            return;
                        }
                        const list = getAccounts();
                        const idx = list.findIndex(function(u) { return u.id === userId; });
                        if (idx < 0) {
                            return;
                        }

                        const user = list[idx];
                        if (user.status === 'deleted') {
                            msg('Không thể đổi vai trò cho tài khoản đã xóa.', false);
                            return;
                        }

                        const roleSelect = root.querySelector('.account-role-select[data-role-id="' + userId + '"]');
                        const nextRole = roleSelect ? roleSelect.value : '';
                        if (nextRole !== 'superadmin' && nextRole !== 'staff') {
                            msg('Vai trò không hợp lệ.', false);
                            return;
                        }

                        if (user.role === nextRole) {
                            msg('Vai trò chưa thay đổi.', false);
                            return;
                        }

                        const activeSuperadmins = list.filter(function(u) {
                            return u.role === 'superadmin' && u.status === 'active';
                        }).length;

                        if (user.id === currentUser.id && nextRole !== 'superadmin') {
                            msg('Bạn không thể tự hạ quyền tài khoản đang đăng nhập.', false);
                            return;
                        }

                        if (user.role === 'superadmin' && nextRole !== 'superadmin' && activeSuperadmins <= 1) {
                            msg('Phải giữ lại ít nhất 1 quản trị cao nhất đang hoạt động.', false);
                            return;
                        }

                        list[idx].role = nextRole;
                        list[idx].updatedAt = Date.now();
                        saveAccounts(list);
                        msg('Đã cập nhật vai trò thành công.', true);
                        render();
                        return;
                    }

                    if (!userId) {
                        return;
                    }

                    const list = getAccounts();
                    const idx = list.findIndex(function(u) { return u.id === userId; });
                    if (idx < 0) {
                        return;
                    }
                    const user = list[idx];

                    if (action === 'backup') {
                        const allBackups = getBackups();
                        allBackups.unshift({
                            id: 'b_' + Date.now(),
                            userId: user.id,
                            userName: user.fullName || user.username,
                            createdAt: Date.now(),
                            dataSnapshot: JSON.parse(JSON.stringify(user.data || {}))
                        });
                        saveBackups(allBackups.slice(0, 100));
                        msg('Đã sao lưu dữ liệu tài khoản.', true);
                        render();
                        return;
                    }

                    if (action === 'restore-data') {
                        const allBackups = getBackups();
                        const latest = allBackups.find(function(b) { return b.userId === user.id; });
                        if (!latest) {
                            msg('Tài khoản này chưa có bản sao lưu dữ liệu.', false);
                            return;
                        }
                        list[idx].data = latest.dataSnapshot || {};
                        list[idx].updatedAt = Date.now();
                        saveAccounts(list);
                        msg('Đã khôi phục dữ liệu tài khoản.', true);
                        render();
                        return;
                    }

                    if (action === 'delete') {
                        if (user.id === currentUser.id) {
                            msg('Không thể tự xóa tài khoản đang đăng nhập.', false);
                            return;
                        }
                        const allBackups = getBackups();
                        allBackups.unshift({
                            id: 'b_' + Date.now(),
                            userId: user.id,
                            userName: user.fullName || user.username,
                            createdAt: Date.now(),
                            dataSnapshot: JSON.parse(JSON.stringify(user.data || {}))
                        });
                        saveBackups(allBackups.slice(0, 100));

                        list[idx].status = 'deleted';
                        list[idx].updatedAt = Date.now();
                        saveAccounts(list);
                        msg('Đã xóa tài khoản (có thể khôi phục).', true);
                        render();
                        return;
                    }

                    if (action === 'approve') {
                        list[idx].status = 'active';
                        list[idx].updatedAt = Date.now();
                        saveAccounts(list);
                        msg('Đã duyệt tài khoản. Tài khoản này có thể đăng nhập.', true);
                        render();
                        return;
                    }

                    if (action === 'restore') {
                        list[idx].status = 'active';
                        list[idx].updatedAt = Date.now();
                        saveAccounts(list);
                        msg('Đã khôi phục tài khoản.', true);
                        render();
                    }
                });
            });
        };

        render();
    };

    const bootAuthSystem = function() {
        addAuthStyles();
        ensureDemoStaffAccounts();

        if (!ensureOwnerExists()) {
            setSiteLocked(true);
            showAuthModal('setup-owner');
            return;
        }

        const currentUser = getCurrentUser();
        mountAuthBadge(currentUser);

        if (!currentUser) {
            setSiteLocked(true);
            showAuthModal('choice');
            initAccountManager(null);
            return;
        }

        setSiteLocked(false);
        initAccountManager(currentUser);
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootAuthSystem);
    } else {
        bootAuthSystem();
    }
}());
